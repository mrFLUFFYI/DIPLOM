﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for Edit_ZaivkaMeneger_Window.xaml
    /// </summary>
    public partial class Edit_ZaivkaMeneger_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Edit_ZaivkaMeneger_Window()
        {
            InitializeComponent();
        }
        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            Zaivka_Meneger_Window car = new Zaivka_Meneger_Window();
            car.Show();
            this.Close();
        }
        private void Edit_Click(object sender, RoutedEventArgs e)
        {
                int x = Convert.ToInt32(PublicZaivka.ID);
                var str = db.DIPLOM_Zakaz.Where(w => w.ID == x).FirstOrDefault();

                str.ID_klienta = db.DIPLOM_Klient.Where(w => w.Familia == cmbFIO.Text).Select(w => w.ID).FirstOrDefault();
                str.ID_sotrydnika = db.DIPLOM_Sotrydniki.Where(w => w.Familia == cmbFIOs.Text).Select(w => w.ID).FirstOrDefault();
                str.ID_vida_oplati = db.DIPLOM_Vid_oplati.Where(w => w.Vid_oplati == cmbVidOplati.Text).Select(w => w.ID).FirstOrDefault();
                str.ID_yslygi = db.DIPLOM_Yslyga.Where(w => w.Nazvanie == cmbYslyga.Text).Select(w => w.ID).FirstOrDefault();
                str.Data = DatePicker.SelectedDate;
                db.SaveChanges();
                MessageBox.Show("Запись изменена!", "Успешно");

            Zaivka_Meneger_Window car = new Zaivka_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            int ID_klienta = PublicZaivka.ID_klienta;
            cmbFIO.Text = db.DIPLOM_Klient.Where(w => w.ID == ID_klienta).Select(w => w.Familia).FirstOrDefault();

            int ID_sotrydnika = PublicZaivka.ID_sotrydnika;
            cmbFIOs.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID_sotrydnika).Select(w => w.Familia).FirstOrDefault();

            int ID_vida_oplati = PublicZaivka.ID_vida_oplati;
            cmbVidOplati.Text = db.DIPLOM_Vid_oplati.Where(w => w.ID == ID_vida_oplati).Select(w => w.Vid_oplati).FirstOrDefault();

            int ID_yslygi = PublicZaivka.ID_yslygi;
            cmbYslyga.Text = db.DIPLOM_Yslyga.Where(w => w.ID == ID_yslygi).Select(w => w.Nazvanie).FirstOrDefault();

            DatePicker.SelectedDate = Convert.ToDateTime(PublicKlient.Data_rojdenia);

            var Klient = db.DIPLOM_Klient.ToList();
            cmbFIO.ItemsSource = Klient;
            cmbFIO.DisplayMemberPath = "Familia";

            var Sotrydnik = db.DIPLOM_Sotrydniki.ToList();
            cmbFIOs.ItemsSource = Sotrydnik;
            cmbFIOs.DisplayMemberPath = "Familia";

            var Vid = db.DIPLOM_Vid_oplati.ToList();
            cmbVidOplati.ItemsSource = Vid;
            cmbVidOplati.DisplayMemberPath = "Vid_oplati";

            var Yslyga = db.DIPLOM_Yslyga.ToList();
            cmbYslyga.ItemsSource = Yslyga;
            cmbYslyga.DisplayMemberPath = "Nazvanie";
        }
    }
}
