﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for Car_Meneger_Window.xaml
    /// </summary>
    public partial class Car_Meneger_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Car_Meneger_Window()
        {
            InitializeComponent();
            update();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Avtomobili in db.DIPLOM_Avtomobili
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Avtomobili.ID_klienta equals DIPLOM_Klient.ID
                         join DIPLOM_Marka in db.DIPLOM_Marka on DIPLOM_Avtomobili.ID_Marki equals DIPLOM_Marka.ID
                         join DIPLOM_Model in db.DIPLOM_Model on DIPLOM_Avtomobili.ID_modeli equals DIPLOM_Model.ID
                         join DIPLOM_Kyzov in db.DIPLOM_Kyzov on DIPLOM_Avtomobili.ID_kyzova equals DIPLOM_Kyzov.ID

                         select new
                         {
                             ID = DIPLOM_Avtomobili.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Nomer_avtomobila = DIPLOM_Avtomobili.Nomer_avtomobila,
                             Marka = DIPLOM_Marka.Marka,
                             Model = DIPLOM_Model.Model,
                             Kyzov = DIPLOM_Kyzov.Kyzov,
                             God = DIPLOM_Avtomobili.God + "год"
                         };
            membersDataGrid.ItemsSource = result.ToList();
            textBoxFilter.Text = "Поиск";
            textBoxFilter.GotFocus += RemoveText;
            textBoxFilter.LostFocus += AddText;
        }
        public void RemoveText(object sender, EventArgs e)
        {
            if (textBoxFilter.Text == "Поиск")
            {
                textBoxFilter.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxFilter.Text))
                textBoxFilter.Text = "Поиск";
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MenegjerMain main = new MenegjerMain();
            main.Show();
            this.Close();
        }

        private void ClickYslygi(object sender, RoutedEventArgs e)
        {
            Yslygi_Menedjer_Window yslyga = new Yslygi_Menedjer_Window();
            yslyga.Show();
            this.Close();
        }

        private void ClickSotrydnik(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Menedjer_Window sotrydnik = new Sotrydniki_Menedjer_Window();
            sotrydnik.Show();
            this.Close();
        }

        private void Klient_Click(object sender, MouseButtonEventArgs e)
        {
            Klient_Manager_Window klient = new Klient_Manager_Window();
            klient.Show();
            this.Close();
        }

        private void Car_Click(object sender, RoutedEventArgs e)
        {
            Car_Meneger_Window car = new Car_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void ZaivkaClick(object sender, RoutedEventArgs e)
        {
            Zaivka_Meneger_Window zaivka = new Zaivka_Meneger_Window();
            zaivka.Show();
            this.Close();
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }

        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }


        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Avtomobili in db.DIPLOM_Avtomobili
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Avtomobili.ID_klienta equals DIPLOM_Klient.ID
                         join DIPLOM_Marka in db.DIPLOM_Marka on DIPLOM_Avtomobili.ID_Marki equals DIPLOM_Marka.ID
                         join DIPLOM_Model in db.DIPLOM_Model on DIPLOM_Avtomobili.ID_modeli equals DIPLOM_Model.ID
                         join DIPLOM_Kyzov in db.DIPLOM_Kyzov on DIPLOM_Avtomobili.ID_kyzova equals DIPLOM_Kyzov.ID

                         select new
                         {
                             ID = DIPLOM_Avtomobili.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Nomer_avtomobila = DIPLOM_Avtomobili.Nomer_avtomobila,
                             Marka = DIPLOM_Marka.Marka,
                             Model = DIPLOM_Model.Model,
                             Kyzov = DIPLOM_Kyzov.Kyzov,
                             God = DIPLOM_Avtomobili.God
                         };
            membersDataGrid.ItemsSource = result.ToList();
        }

        private void textBoxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBoxFilter.Text == "")
            {
                var result = from DIPLOM_Avtomobili in db.DIPLOM_Avtomobili
                             join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Avtomobili.ID_klienta equals DIPLOM_Klient.ID
                             join DIPLOM_Marka in db.DIPLOM_Marka on DIPLOM_Avtomobili.ID_Marki equals DIPLOM_Marka.ID
                             join DIPLOM_Model in db.DIPLOM_Model on DIPLOM_Avtomobili.ID_modeli equals DIPLOM_Model.ID
                             join DIPLOM_Kyzov in db.DIPLOM_Kyzov on DIPLOM_Avtomobili.ID_kyzova equals DIPLOM_Kyzov.ID

                             select new
                             {
                                 ID = DIPLOM_Avtomobili.ID,
                                 FK = DIPLOM_Klient.Familia,
                                 IK = DIPLOM_Klient.Ima,
                                 OK = DIPLOM_Klient.Otchestvo,
                                 Nomer_avtomobila = DIPLOM_Avtomobili.Nomer_avtomobila,
                                 Marka = DIPLOM_Marka.Marka,
                                 Model = DIPLOM_Model.Model,
                                 Kyzov = DIPLOM_Kyzov.Kyzov,
                                 God = DIPLOM_Avtomobili.God
                             };
                membersDataGrid.ItemsSource = result.ToList();
            }
        }

        private void textBoxFilter_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var result = from DIPLOM_Avtomobili in db.DIPLOM_Avtomobili
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Avtomobili.ID_klienta equals DIPLOM_Klient.ID
                         join DIPLOM_Marka in db.DIPLOM_Marka on DIPLOM_Avtomobili.ID_Marki equals DIPLOM_Marka.ID
                         join DIPLOM_Model in db.DIPLOM_Model on DIPLOM_Avtomobili.ID_modeli equals DIPLOM_Model.ID
                         join DIPLOM_Kyzov in db.DIPLOM_Kyzov on DIPLOM_Avtomobili.ID_kyzova equals DIPLOM_Kyzov.ID

                         select new
                         {
                             ID = DIPLOM_Avtomobili.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Nomer_avtomobila = DIPLOM_Avtomobili.Nomer_avtomobila,
                             Marka = DIPLOM_Marka.Marka,
                             Model = DIPLOM_Model.Model,
                             Kyzov = DIPLOM_Kyzov.Kyzov,
                             God = DIPLOM_Avtomobili.God
                         };
            membersDataGrid.ItemsSource = result.Where(item => item.FK == textBoxFilter.Text || item.FK.Contains(textBoxFilter.Text) ||
            item.IK == textBoxFilter.Text || item.IK.Contains(textBoxFilter.Text) ||
            item.OK == textBoxFilter.Text || item.OK.Contains(textBoxFilter.Text) ||
            item.Nomer_avtomobila == textBoxFilter.Text || item.Nomer_avtomobila.Contains(textBoxFilter.Text) ||
            item.Marka == textBoxFilter.Text || item.Marka.Contains(textBoxFilter.Text) ||
            item.Model == textBoxFilter.Text || item.Model.Contains(textBoxFilter.Text) ||
            item.Kyzov == textBoxFilter.Text || item.Kyzov.Contains(textBoxFilter.Text)
                ).ToList();
        }

        internal class Car
        {
            public int index;
            public int ID;
            public int ID_klienta;
            public string Nomer_avtomobila;
            public int ID_Marki;
            public int ID_modeli;
            public int ID_kyzova;
            public string God;
        }

        List<Car> LisPR;
        void update()
        {
            int i = 0;

            LisPR = new List<Car>();
            foreach (DIPLOM_Avtomobili item in App.Context.DIPLOM_Avtomobili.ToList())
            {
                Car npr = new Car();
                npr.index = i;
                npr.ID = Convert.ToInt16(item.ID);
                npr.ID_klienta = Convert.ToInt16(item.ID_klienta);
                npr.Nomer_avtomobila = item.Nomer_avtomobila;
                npr.ID_Marki = Convert.ToInt16(item.ID_Marki);
                npr.ID_modeli = Convert.ToInt16(item.ID_modeli);
                npr.ID_kyzova = Convert.ToInt16(item.ID_kyzova);
                npr.God = item.God;


                i += 1;
                LisPR.Add(npr);
            }
        }

        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            Insert_CarMeneger_Window insert = new Insert_CarMeneger_Window();
            insert.Show();
            this.Close();
        }

        private void ClickEdit(object sender, RoutedEventArgs e)
        {
            List<DIPLOM_Avtomobili> list = App.Context.DIPLOM_Avtomobili.ToList();
            int x = membersDataGrid.SelectedIndex;


            Car f = LisPR.Where(i => i.index == x).FirstOrDefault();
            PublicCar.index = Convert.ToInt32(f.index);
            PublicCar.ID = Convert.ToInt32(f.ID);
            PublicCar.ID_klienta = Convert.ToInt32(f.ID_klienta);
            PublicCar.Nomer_avtomobila = f.Nomer_avtomobila; ToString();
            PublicCar.ID_Marki = Convert.ToInt32(f.ID_Marki);
            PublicCar.ID_modeli = Convert.ToInt32(f.ID_modeli);
            PublicCar.ID_kyzova = Convert.ToInt32(f.ID_kyzova);
            PublicCar.God = f.God; ToString();

            Edit_CarMeneger_Window edit = new Edit_CarMeneger_Window();
            edit.Show();
            this.Close();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Avtomobili in db.DIPLOM_Avtomobili
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Avtomobili.ID_klienta equals DIPLOM_Klient.ID
                         join DIPLOM_Marka in db.DIPLOM_Marka on DIPLOM_Avtomobili.ID_Marki equals DIPLOM_Marka.ID
                         join DIPLOM_Model in db.DIPLOM_Model on DIPLOM_Avtomobili.ID_modeli equals DIPLOM_Model.ID
                         join DIPLOM_Kyzov in db.DIPLOM_Kyzov on DIPLOM_Avtomobili.ID_kyzova equals DIPLOM_Kyzov.ID

                         select new
                         {
                             ID = DIPLOM_Avtomobili.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Nomer_avtomobila = DIPLOM_Avtomobili.Nomer_avtomobila,
                             Marka = DIPLOM_Marka.Marka,
                             Model = DIPLOM_Model.Model,
                             Kyzov = DIPLOM_Kyzov.Kyzov,
                             God = DIPLOM_Avtomobili.God
                         };

            List<DIPLOM_Avtomobili> list = App.Context.DIPLOM_Avtomobili.ToList();
            int x = membersDataGrid.SelectedIndex;


            Car f = LisPR.Where(i => i.index == x).FirstOrDefault();
            PublicCar.ID = Convert.ToInt16(f.ID);
            int num = Convert.ToInt16(PublicCar.ID);

            var dRow = db.DIPLOM_Avtomobili.Where(w => w.ID == num).FirstOrDefault();
            db.DIPLOM_Avtomobili.Remove(dRow);
            db.SaveChanges();
            membersDataGrid.ItemsSource = result.ToList();

            MessageBox.Show("Запись удалена", "Успешно", MessageBoxButton.OK);

        }
    }
}
