﻿using DIPLOM.Menedjer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM
{
    /// <summary>
    /// Interaction logic for Yslygi_Window.xaml
    /// </summary>
    public partial class Yslygi_Menedjer_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Yslygi_Menedjer_Window()
        {
            InitializeComponent();
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MenegjerMain main = new MenegjerMain();
            main.Show();
            this.Close();
        }

        private void ClickYslygi(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Menedjer_Window yslygi = new Sotrydniki_Menedjer_Window();
            yslygi.Show();
            this.Close();
        }

        private void ClickSotrydnik(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Menedjer_Window sotrydniki = new Sotrydniki_Menedjer_Window();
            sotrydniki.Show();
            this.Close();
        }

        private void ZaivkaClick(object sender, RoutedEventArgs e)
        {
            Zaivka_Meneger_Window zaivka = new Zaivka_Meneger_Window();
            zaivka.Show();
            this.Close();
        }

        private void textBoxFilter_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxFilter.Text))
            {
                list.ItemsSource = db.DIPLOM_Yslyga.ToList();
            }
            else
            {
                list.ItemsSource = db.DIPLOM_Yslyga.Where(w => w.Nazvanie.ToString().Contains(textBoxFilter.Text.ToLower())).ToList();
            }
        }

        private void textBoxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBoxFilter.Text == "")
            {
                list.ItemsSource = db.DIPLOM_Yslyga.ToList();
            }
         }
        public void RemoveText(object sender, EventArgs e)
        {
            if (textBoxFilter.Text == "Поиск")
            {
                textBoxFilter.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxFilter.Text))
                textBoxFilter.Text = "Поиск";
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            list.ItemsSource = db.DIPLOM_Yslyga.ToList();
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            list.ItemsSource = db.DIPLOM_Yslyga.ToList();
            textBoxFilter.Text = "Поиск";
            textBoxFilter.GotFocus += RemoveText;
            textBoxFilter.LostFocus += AddText;
        }

        private void about(object sender, RoutedEventArgs e)
        {
            PublicYslygi.about = ((Button)sender).Tag.ToString();
            About_Yslygi_Window about = new About_Yslygi_Window();
            about.Show();
        }

        private void Klient_Click(object sender, MouseButtonEventArgs e)
        {
            Klient_Manager_Window klient = new Klient_Manager_Window();
            klient.Show();
            this.Close();
        }

        private void Car_Click(object sender, RoutedEventArgs e)
        {
            Car_Meneger_Window car = new Car_Meneger_Window();
            car.Show();
            this.Close();
        }
    }
}
