﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for MenegjerMain.xaml
    /// </summary>
    public partial class MenegjerMain : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        private DispatcherTimer timer;
        public MenegjerMain()
        {
            InitializeComponent();
            InitializeTimer();
        }

        private void InitializeTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(100);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            string currentTime = now.ToString("HH:mm:ss");
            string currentDate = now.ToString("dd MMMM yyyy");
            DateTimeTextBlock.Text = $"{currentTime} {currentDate}";
        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var ID = db.DIPLOM_Sotrydniki.Where(w => w.Login == PublicSotr.Login).Select(w => w.ID).FirstOrDefault();
            txtFamilia.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Familia).FirstOrDefault();
            txtIma.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Ima).FirstOrDefault();
            txtOtchestvo.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Otchestvo).FirstOrDefault();
            txtdata.Text = Convert.ToString(db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Data_rojdenia).FirstOrDefault());
            txtTelefon.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Telefon).FirstOrDefault();
            txtEmail.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Email).FirstOrDefault();
            txtAdres.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Adress).FirstOrDefault();
            txtStaj.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Staj).FirstOrDefault();
            txtDoljnost.Text = db.DIPLOM_Doljnost.Where(w => w.ID == ID).Select(w => w.Doljnost).FirstOrDefault();
            txtLogin.Text = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Login).FirstOrDefault();

        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MenegjerMain main = new MenegjerMain();
            main.Show();
            this.Close();
        }

        private void ClickYslygi(object sender, RoutedEventArgs e)
        {
            Yslygi_Menedjer_Window yslyga  = new Yslygi_Menedjer_Window();
            yslyga.Show();
            this.Close();
        }

        private void ClickSotrydnik(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Menedjer_Window sotrydnik = new Sotrydniki_Menedjer_Window();
            sotrydnik.Show();
            this.Close();
        }

        private void Klient_Click(object sender, MouseButtonEventArgs e)
        {
            Klient_Manager_Window klient = new Klient_Manager_Window();
            klient.Show();
            this.Close();
        }

        private void Car_Click(object sender, RoutedEventArgs e)
        {
            Car_Meneger_Window car = new Car_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void ZaivkaClick(object sender, RoutedEventArgs e)
        {
            Zaivka_Meneger_Window zaivka = new Zaivka_Meneger_Window();
            zaivka.Show();
            this.Close();
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow auth = new AuthorizationWindow();
            auth.Show();
            this.Close();
        }
    }
}
