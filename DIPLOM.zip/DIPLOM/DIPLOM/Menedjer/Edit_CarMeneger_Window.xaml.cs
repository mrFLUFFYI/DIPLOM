﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for Edit_CarMeneger_Window.xaml
    /// </summary>
    public partial class Edit_CarMeneger_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Edit_CarMeneger_Window()
        {
            InitializeComponent();
        }

        private void txtNalichie_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            Car_Meneger_Window car = new Car_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (txtGod.Text == "" || txtNomer.Text == "")
            {
                MessageBox.Show("Заполните все поля!");
            }
            else
            {

                int x = Convert.ToInt32(PublicCar.ID);
                var str = db.DIPLOM_Avtomobili.Where(w => w.ID == x).FirstOrDefault();

                str.ID_klienta = db.DIPLOM_Klient.Where(w => w.Familia == cmbFIO.Text).Select(w => w.ID).FirstOrDefault();
                str.Nomer_avtomobila = txtNomer.Text;
                str.ID_Marki = db.DIPLOM_Marka.Where(w => w.Marka == cmbMarka.Text).Select(w => w.ID).FirstOrDefault();
                str.ID_modeli = db. DIPLOM_Model.Where(w => w.Model == cmbModel.Text).Select(w => w.ID).FirstOrDefault();
                str.ID_kyzova = db.DIPLOM_Kyzov.Where(w => w.Kyzov == cmbKyzov.Text).Select(w => w.ID).FirstOrDefault();
                str.God = txtGod.Text;
                db.SaveChanges();
                MessageBox.Show("Запись изменена!", "Успешно");

                Car_Meneger_Window car = new Car_Meneger_Window();
                car.Show();
                this.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            int ID_klienta = PublicCar.ID_klienta;
            cmbFIO.Text = db.DIPLOM_Klient.Where(w => w.ID == ID_klienta).Select(w => w.Familia).FirstOrDefault();

            txtNomer.Text = PublicCar.Nomer_avtomobila;

            int ID_Marki = PublicCar.ID_Marki;
            cmbMarka.Text = db.DIPLOM_Marka.Where(w => w.ID == ID_Marki).Select(w => w.Marka).FirstOrDefault();

            int ID_modeli = PublicCar.ID_modeli;
            cmbModel.Text = db.DIPLOM_Model.Where(w => w.ID == ID_modeli).Select(w => w.Model).FirstOrDefault();

            int ID_kyzova = PublicCar.ID_kyzova;
            cmbKyzov.Text = db.DIPLOM_Kyzov.Where(w => w.ID == ID_kyzova).Select(w => w.Kyzov).FirstOrDefault();

            txtGod.Text = PublicCar.God;

            var Klient = db.DIPLOM_Klient.ToList();
            cmbFIO.ItemsSource = Klient;
            cmbFIO.DisplayMemberPath = "Familia";

            var Marka = db.DIPLOM_Marka.ToList();
            cmbMarka.ItemsSource = Marka;
            cmbMarka.DisplayMemberPath = "Marka";

            var Model = db.DIPLOM_Model.ToList();
            cmbModel.ItemsSource = Model;
            cmbModel.DisplayMemberPath = "Model";

            var Kyzov = db.DIPLOM_Kyzov.ToList();
            cmbKyzov.ItemsSource = Kyzov;
            cmbKyzov.DisplayMemberPath = "Kyzov";
        }
    }
}
