﻿using DIPLOM.Klient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for Klient_Manager_Window.xaml
    /// </summary>
    public partial class Klient_Manager_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Klient_Manager_Window()
        {
            InitializeComponent();
            update();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Klient in db.DIPLOM_Klient

                         select new
                         {
                             ID = DIPLOM_Klient.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Telefon = DIPLOM_Klient.Telefon,
                             Data_rojdenia = DIPLOM_Klient.Data_rojdenia,
                             Pasport_seria = DIPLOM_Klient.Pasport_seria,
                             Pasport_nomer = DIPLOM_Klient.Pasport_nomer,
                             Login = DIPLOM_Klient.Login,
                             Password = DIPLOM_Klient.Password
                         };
            membersDataGrid.ItemsSource = result.ToList();
            textBoxFilter.Text = "Поиск";
            textBoxFilter.GotFocus += RemoveText;
            textBoxFilter.LostFocus += AddText;
        }
        public void RemoveText(object sender, EventArgs e)
        {
            if (textBoxFilter.Text == "Поиск")
            {
                textBoxFilter.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxFilter.Text))
                textBoxFilter.Text = "Поиск";
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MenegjerMain main = new MenegjerMain();
            main.Show();
            this.Close();
        }

        private void ClickYslygi(object sender, RoutedEventArgs e)
        {
            Yslygi_Menedjer_Window yslyga = new Yslygi_Menedjer_Window();
            yslyga.Show();
            this.Close();
        }

        private void ClickSotrydnik(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Menedjer_Window sotrydnik = new Sotrydniki_Menedjer_Window();
            sotrydnik.Show();
            this.Close();
        }
        private void Klient_Click(object sender, MouseButtonEventArgs e)
        {
            Klient_Manager_Window klient = new Klient_Manager_Window();
            klient.Show();
            this.Close();
        }

        private void Car_Click(object sender, RoutedEventArgs e)
        {
            Car_Meneger_Window car = new Car_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void ZaivkaClick(object sender, RoutedEventArgs e)
        {
            Zaivka_Meneger_Window zaivka = new Zaivka_Meneger_Window();
            zaivka.Show();
            this.Close();
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            Insert_KlientMenger_Window insert = new Insert_KlientMenger_Window();
            insert.Show();
            this.Close();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Klient in db.DIPLOM_Klient

                         select new
                         {
                             ID = DIPLOM_Klient.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Telefon = DIPLOM_Klient.Telefon,
                             Data_rojdenia = DIPLOM_Klient.Data_rojdenia,
                             Pasport_seria = DIPLOM_Klient.Pasport_seria,
                             Pasport_nomer = DIPLOM_Klient.Pasport_nomer,
                             Login = DIPLOM_Klient.Login,
                             Password = DIPLOM_Klient.Password
                         };
            membersDataGrid.ItemsSource = result.ToList();
        }

        private void textBoxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBoxFilter.Text == "")
            {
                var result = from DIPLOM_Klient in db.DIPLOM_Klient

                             select new
                             {
                                 ID = DIPLOM_Klient.ID,
                                 FK = DIPLOM_Klient.Familia,
                                 IK = DIPLOM_Klient.Ima,
                                 OK = DIPLOM_Klient.Otchestvo,
                                 Telefon = DIPLOM_Klient.Telefon,
                                 Data_rojdenia = DIPLOM_Klient.Data_rojdenia,
                                 Pasport_seria = DIPLOM_Klient.Pasport_seria,
                                 Pasport_nomer = DIPLOM_Klient.Pasport_nomer,
                                 Login = DIPLOM_Klient.Login,
                                 Password = DIPLOM_Klient.Password
                             };
                membersDataGrid.ItemsSource = result.ToList();
            }

         }

        private void textBoxFilter_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var result = from DIPLOM_Klient in db.DIPLOM_Klient

                         select new
                         {
                             ID = DIPLOM_Klient.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Telefon = DIPLOM_Klient.Telefon,
                             Data_rojdenia = DIPLOM_Klient.Data_rojdenia,
                             Pasport_seria = DIPLOM_Klient.Pasport_seria,
                             Pasport_nomer = DIPLOM_Klient.Pasport_nomer,
                             Login = DIPLOM_Klient.Login,
                             Password = DIPLOM_Klient.Password
                         };
            membersDataGrid.ItemsSource = result.Where(item => item.FK == textBoxFilter.Text || item.FK.Contains(textBoxFilter.Text) ||
            item.IK == textBoxFilter.Text || item.IK.Contains(textBoxFilter.Text) ||
            item.OK == textBoxFilter.Text || item.OK.Contains(textBoxFilter.Text) ||
            item.Telefon == textBoxFilter.Text || item.Telefon.Contains(textBoxFilter.Text) ||
            item.Pasport_seria == textBoxFilter.Text || item.Pasport_seria.Contains(textBoxFilter.Text) ||
            item.Pasport_nomer == textBoxFilter.Text || item.Pasport_nomer.Contains(textBoxFilter.Text) ||
            item.Login == textBoxFilter.Text || item.Login.Contains(textBoxFilter.Text)
            ).ToList();


        }

        private void ClickEdit(object sender, RoutedEventArgs e)
        {
            List<DIPLOM_Klient> list = App.Context.DIPLOM_Klient.ToList();
            int x = membersDataGrid.SelectedIndex;


            Klient f = LisPR.Where(i => i.index == x).FirstOrDefault();
            PublicKlient.index = Convert.ToInt32(f.index);
            PublicKlient.ID = Convert.ToInt32(f.index);
            PublicKlient.Familia = f.Familia; ToString();
            PublicKlient.Ima = f.Ima; ToString();
            PublicKlient.Otchestvo = f.Otchestvo; ToString();
            PublicKlient.Data_rojdenia = Convert.ToDateTime(f.Data_rojdenia); ToString();
            PublicKlient.Pasport_seria = f.Pasport_seria; ToString();
            PublicKlient.Pasport_nomer = f.Pasport_nomer; ToString();
            PublicKlient.Login = f.Login; ToString();
            PublicKlient.Password = f.Password; ToString();

            Edit_KlientMeneger_Window edit = new Edit_KlientMeneger_Window();
            edit.Show();
            this.Close();
        }

        internal class Klient
        {
            public int index;
            public int ID;
            public string Familia;
            public string Ima;
            public string Otchestvo;
            public string Telefon;
            public DateTime Data_rojdenia;
            public string Pasport_seria;
            public string Pasport_nomer;
            public string Login;
            public string Password;

        }
        List<Klient> LisPR;
        void update()
        {
            int i = 0;

            LisPR = new List<Klient>();
            foreach (DIPLOM_Klient item in App.Context.DIPLOM_Klient.ToList())
            {
                Klient npr = new Klient();
                npr.index = i;
                npr.ID = Convert.ToInt16(item.ID);
                npr.Familia = item.Familia;
                npr.Ima = item.Ima;
                npr.Otchestvo = item.Otchestvo;
                npr.Telefon = item.Telefon;
                npr.Data_rojdenia = Convert.ToDateTime(item.Data_rojdenia);
                npr.Pasport_seria = item.Pasport_seria;
                npr.Pasport_nomer = item.Pasport_nomer;
                npr.Login = item.Login;
                npr.Password = item.Password;
                i += 1;
                LisPR.Add(npr);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Klient in db.DIPLOM_Klient

                         select new
                         {
                             ID = DIPLOM_Klient.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             Telefon = DIPLOM_Klient.Telefon,
                             Data_rojdenia = DIPLOM_Klient.Data_rojdenia,
                             Pasport_seria = DIPLOM_Klient.Pasport_seria,
                             Pasport_nomer = DIPLOM_Klient.Pasport_nomer,
                             Login = DIPLOM_Klient.Login,
                             Password = DIPLOM_Klient.Password
                         };

            List<DIPLOM_Klient> list = App.Context.DIPLOM_Klient.ToList();
            int x = membersDataGrid.SelectedIndex;


            Klient f = LisPR.Where(i => i.index == x).FirstOrDefault();
            PublicKlient.ID = Convert.ToInt16(f.ID);
            int num = Convert.ToInt16(PublicKlient.ID);

            var dRow = db.DIPLOM_Klient.Where(w => w.ID == num).FirstOrDefault();
            db.DIPLOM_Klient.Remove(dRow);
            db.SaveChanges();
            membersDataGrid.ItemsSource = result.ToList();

            MessageBox.Show("Запись удалена", "Успешно", MessageBoxButton.OK);
        }
    }
}
