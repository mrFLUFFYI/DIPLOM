﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for Insert_ZaivkaMeneger_Window.xaml
    /// </summary>
    public partial class Insert_ZaivkaMeneger_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Insert_ZaivkaMeneger_Window()
        {
            InitializeComponent();
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            Zaivka_Meneger_Window car = new Zaivka_Meneger_Window();
            car.Show();
            this.Close();
        }
        //Функция добавления данных
        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            DIPLOM_Zakaz str = new DIPLOM_Zakaz();

            str.ID_klienta = db.DIPLOM_Klient.Where(w => w.Familia == cmbFIO.Text).Select(w => w.ID).FirstOrDefault();
            str.ID_sotrydnika = db.DIPLOM_Sotrydniki.Where(w => w.Familia == cmbFIOs.Text).Select(w => w.ID).FirstOrDefault();
            str.ID_vida_oplati = db.DIPLOM_Vid_oplati.Where(w => w.Vid_oplati == cmbVidOplati.Text).Select(w => w.ID).FirstOrDefault();
            str.ID_yslygi = db.DIPLOM_Yslyga.Where(w => w.Nazvanie == cmbYslyga.Text).Select(w => w.ID).FirstOrDefault();
            str.Data = DatePicker.SelectedDate;
            db.DIPLOM_Zakaz.Add(str);
            db.SaveChanges();
            MessageBox.Show("Запись добавлена!", "Успешно");

            Zaivka_Meneger_Window car = new Zaivka_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var Klient = db.DIPLOM_Klient.ToList();
            cmbFIO.ItemsSource = Klient;
            cmbFIO.DisplayMemberPath = "Familia";

            var Sotrydnik = db.DIPLOM_Sotrydniki.ToList();
            cmbFIOs.ItemsSource = Sotrydnik;
            cmbFIOs.DisplayMemberPath = "Familia";

            var Vid = db.DIPLOM_Vid_oplati.ToList();
            cmbVidOplati.ItemsSource = Vid;
            cmbVidOplati.DisplayMemberPath = "Vid_oplati";

            var Yslyga = db.DIPLOM_Yslyga.ToList();
            cmbYslyga.ItemsSource = Yslyga;
            cmbYslyga.DisplayMemberPath = "Nazvanie";
        }
    }
}
