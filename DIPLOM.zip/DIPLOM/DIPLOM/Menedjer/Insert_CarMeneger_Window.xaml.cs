﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for Insert_CarMeneger_Window.xaml
    /// </summary>
    public partial class Insert_CarMeneger_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Insert_CarMeneger_Window()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var Klient = db.DIPLOM_Klient.ToList();
            cmbFIO.ItemsSource = Klient;
            cmbFIO.DisplayMemberPath = "Familia";

            var Marka = db.DIPLOM_Marka.ToList();
            cmbMarka.ItemsSource = Marka;
            cmbMarka.DisplayMemberPath = "Marka";

            var Model = db.DIPLOM_Model.ToList();
            cmbModel.ItemsSource = Model;
            cmbModel.DisplayMemberPath = "Model";

            var Kyzov = db.DIPLOM_Kyzov.ToList();
            cmbKyzov.ItemsSource = Kyzov;
            cmbKyzov.DisplayMemberPath = "Kyzov";
        }
        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            Car_Meneger_Window car = new Car_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void txtNalichie_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (cmbFIO.SelectedIndex == -1 || cmbMarka.SelectedIndex == -1 || cmbModel.SelectedIndex == -1 || cmbKyzov.SelectedIndex == -1 || txtGod.Text == "" || txtNomer.Text == "")
            {
                MessageBox.Show("Заполните все поля!", "Успешно");
            }
            else
            {
                DIPLOM_Avtomobili str = new DIPLOM_Avtomobili();
                str.ID_klienta = db.DIPLOM_Klient.Where(w => w.Familia == cmbFIO.Text).Select(w => w.ID).FirstOrDefault();
                str.Nomer_avtomobila = txtNomer.Text;
                str.ID_Marki = db.DIPLOM_Marka.Where(w => w.Marka == cmbMarka.Text).Select(w => w.ID).FirstOrDefault();
                str.ID_modeli = db.DIPLOM_Model.Where(w => w.Model == cmbModel.Text).Select(w => w.ID).FirstOrDefault();
                str.ID_kyzova = db.DIPLOM_Kyzov.Where(w => w.Kyzov == cmbKyzov.Text).Select(w => w.ID).FirstOrDefault();
                str.God = txtGod.Text;
                db.DIPLOM_Avtomobili.Add(str);
                db.SaveChanges();
                MessageBox.Show("Запись добавлена!", "Успешно");

                Car_Meneger_Window car = new Car_Meneger_Window();
                car.Show();
                this.Close();
            }
        }
    }
}
