﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static DIPLOM.Menedjer.Car_Meneger_Window;

namespace DIPLOM.Menedjer
{
    /// <summary>
    /// Interaction logic for Zaivka_Meneger_Window.xaml
    /// </summary>
    public partial class Zaivka_Meneger_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Zaivka_Meneger_Window()
        {
            InitializeComponent();
            update();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                         join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Klient.ID
                         join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                         join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                         select new
                         {
                             ID = DIPLOM_Zakaz.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             FS = DIPLOM_Sotrydniki.Familia,
                             IS = DIPLOM_Sotrydniki.Ima,
                             OS = DIPLOM_Sotrydniki.Otchestvo,
                             Yslyga = DIPLOM_Yslyga.Nazvanie,
                             Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                             Date = DIPLOM_Zakaz.Data,
                             Cena = DIPLOM_Yslyga.Stoimost
                         };
            membersDataGrid.ItemsSource = result.ToList();
            textBoxFilter.Text = "Поиск";
            textBoxFilter.GotFocus += RemoveText;
            textBoxFilter.LostFocus += AddText;
        }

        public void RemoveText(object sender, EventArgs e)
        {
            if (textBoxFilter.Text == "Поиск")
            {
                textBoxFilter.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxFilter.Text))
                textBoxFilter.Text = "Поиск";
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MenegjerMain main = new MenegjerMain();
            main.Show();
            this.Close();
        }

        private void ClickYslygi(object sender, RoutedEventArgs e)
        {
            Yslygi_Menedjer_Window yslyga = new Yslygi_Menedjer_Window();
            yslyga.Show();
            this.Close();
        }

        private void ClickSotrydnik(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Menedjer_Window sotrydnik = new Sotrydniki_Menedjer_Window();
            sotrydnik.Show();
            this.Close();
        }

        private void Klient_Click(object sender, MouseButtonEventArgs e)
        {
            Klient_Manager_Window klient = new Klient_Manager_Window();
            klient.Show();
            this.Close();
        }

        private void Car_Click(object sender, RoutedEventArgs e)
        {
            Car_Meneger_Window car = new Car_Meneger_Window();
            car.Show();
            this.Close();
        }

        private void ZaivkaClick(object sender, RoutedEventArgs e)
        {
            Zaivka_Meneger_Window zaivka = new Zaivka_Meneger_Window();
            zaivka.Show();
            this.Close();
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }

        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        //Функциия обновления данных
        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            //Связывание таблиц
            var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                         join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Klient.ID
                         join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                         join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                         select new
                         {
                             //Выбор нужных полей для вывода в таблицу
                             ID = DIPLOM_Zakaz.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             FS = DIPLOM_Sotrydniki.Familia,
                             IS = DIPLOM_Sotrydniki.Ima,
                             OS = DIPLOM_Sotrydniki.Otchestvo,
                             Yslyga = DIPLOM_Yslyga.Nazvanie,
                             Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                             Date = DIPLOM_Zakaz.Data,
                             Cena = DIPLOM_Yslyga.Stoimost
                         };
            membersDataGrid.ItemsSource = result.ToList();
        }

        private void textBoxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBoxFilter.Text == "")
            {
                var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                             join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                             join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Klient.ID
                             join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                             join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                             select new
                             {
                                 ID = DIPLOM_Zakaz.ID,
                                 FK = DIPLOM_Klient.Familia,
                                 IK = DIPLOM_Klient.Ima,
                                 OK = DIPLOM_Klient.Otchestvo,
                                 FS = DIPLOM_Sotrydniki.Familia,
                                 IS = DIPLOM_Sotrydniki.Ima,
                                 OS = DIPLOM_Sotrydniki.Otchestvo,
                                 Yslyga = DIPLOM_Yslyga.Nazvanie,
                                 Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                                 Date = DIPLOM_Zakaz.Data,
                                 Cena = DIPLOM_Yslyga.Stoimost
                             };
                membersDataGrid.ItemsSource = result.ToList();
            }
        }

        private void textBoxFilter_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                         join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Klient.ID
                         join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                         join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                         select new
                         {
                             ID = DIPLOM_Zakaz.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             FS = DIPLOM_Sotrydniki.Familia,
                             IS = DIPLOM_Sotrydniki.Ima,
                             OS = DIPLOM_Sotrydniki.Otchestvo,
                             Yslyga = DIPLOM_Yslyga.Nazvanie,
                             Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                             Date = DIPLOM_Zakaz.Data,
                             Cena = DIPLOM_Yslyga.Stoimost
                         };
            membersDataGrid.ItemsSource = result.Where(item => item.FK == textBoxFilter.Text || item.FK.Contains(textBoxFilter.Text) ||
            item.IK == textBoxFilter.Text || item.IK.Contains(textBoxFilter.Text) ||
            item.OK == textBoxFilter.Text || item.OK.Contains(textBoxFilter.Text) ||
            item.FS == textBoxFilter.Text || item.FK.Contains(textBoxFilter.Text) ||
            item.IS == textBoxFilter.Text || item.IK.Contains(textBoxFilter.Text) ||
            item.OS == textBoxFilter.Text || item.OK.Contains(textBoxFilter.Text) ||
            item.Yslyga == textBoxFilter.Text || item.Yslyga.Contains(textBoxFilter.Text)
            ).ToList();
        }

        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            Insert_ZaivkaMeneger_Window insert = new Insert_ZaivkaMeneger_Window();
            insert.Show();
            this.Close();
        }
        internal class Zaivka
        {
            public int index;
            public int ID;
            public int ID_klienta;
            public int ID_sotrydnika;
            public int ID_vida_oplati;
            public int ID_yslygi;
            public DateTime Data;
        }

        List<Zaivka> LisPR;
        void update()
        {
            int i = 0;

            LisPR = new List<Zaivka>();
            foreach (DIPLOM_Zakaz item in App.Context.DIPLOM_Zakaz.ToList())
            {
                Zaivka npr = new Zaivka();
                npr.index = i;
                npr.ID = Convert.ToInt16(item.ID);
                npr.ID_klienta = Convert.ToInt16(item.ID_klienta);
                npr.ID_sotrydnika = Convert.ToInt16(item.ID_sotrydnika);
                npr.ID_vida_oplati = Convert.ToInt16(item.ID_vida_oplati);
                npr.ID_yslygi = Convert.ToInt16(item.ID_yslygi);
                npr.Data = Convert.ToDateTime(item.Data);
                i += 1;
                LisPR.Add(npr);
            }
        }

        private void ClickEdit(object sender, RoutedEventArgs e)
        {
            List<DIPLOM_Zakaz> list = App.Context.DIPLOM_Zakaz.ToList();
            int x = membersDataGrid.SelectedIndex;


            Zaivka f = LisPR.Where(i => i.index == x).FirstOrDefault();
            PublicZaivka.index = Convert.ToInt32(f.index);
            PublicZaivka.ID = Convert.ToInt32(f.ID);
            PublicZaivka.ID_klienta = Convert.ToInt32(f.ID_klienta);
            PublicZaivka.ID_sotrydnika = Convert.ToInt32(f.ID_sotrydnika);
            PublicZaivka.ID_vida_oplati = Convert.ToInt32(f.ID_vida_oplati);
            PublicZaivka.ID_yslygi = Convert.ToInt32(f.ID_yslygi);
            PublicZaivka.Data = Convert.ToDateTime(f.Data);


            Edit_ZaivkaMeneger_Window edit = new Edit_ZaivkaMeneger_Window();
            edit.Show();
            this.Close();
        }
        //Функция удаления записи
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                         join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                         join DIPLOM_Klient in db.DIPLOM_Klient on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Klient.ID
                         join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                         join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                         select new
                         {
                             ID = DIPLOM_Zakaz.ID,
                             FK = DIPLOM_Klient.Familia,
                             IK = DIPLOM_Klient.Ima,
                             OK = DIPLOM_Klient.Otchestvo,
                             FS = DIPLOM_Sotrydniki.Familia,
                             IS = DIPLOM_Sotrydniki.Ima,
                             OS = DIPLOM_Sotrydniki.Otchestvo,
                             Yslyga = DIPLOM_Yslyga.Nazvanie,
                             Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                             Date = DIPLOM_Zakaz.Data,
                             Cena = DIPLOM_Yslyga.Stoimost
                         };


            List<DIPLOM_Zakaz> list = App.Context.DIPLOM_Zakaz.ToList();
            int x = membersDataGrid.SelectedIndex;


            Zaivka f = LisPR.Where(i => i.index == x).FirstOrDefault();
            PublicZaivka.ID = Convert.ToInt16(f.ID);
            int num = Convert.ToInt16(PublicZaivka.ID);

            var dRow = db.DIPLOM_Zakaz.Where(w => w.ID == num).FirstOrDefault();
            db.DIPLOM_Zakaz.Remove(dRow);
            db.SaveChanges();
            membersDataGrid.ItemsSource = result.ToList();

            MessageBox.Show("Запись удалена", "Успешно", MessageBoxButton.OK);

        }
    }
}
