﻿using DIPLOM.Klient;
using DIPLOM.Menedjer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM
{
    /// <summary>
    /// Interaction logic for AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public AuthorizationWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private int loginAttempts = 0;
        // Авторизация пользователей по ролям
        private void AuthorizationClick(object sender, RoutedEventArgs e)
        {
            //Проверка заполненности полей
            if (string.IsNullOrWhiteSpace(login.Text) || string.IsNullOrWhiteSpace(password.Password))
            {
                MessageBox.Show("Пожалуйста, заполните поля логина и пароля.");
                return;
            }
            //Авторизация для менеджера
            else if (db.DIPLOM_Sotrydniki.Select(w => w.Login + " " + w.Password).Contains(login.Text + " " + password.Password) && db.DIPLOM_Sotrydniki.Select(w => w.ID_Doljnost).Contains(5))
            {
                PublicSotr.Login = login.Text;
                var ID = db.DIPLOM_Sotrydniki.Where(w => w.Login == PublicSotr.Login).Select(w => w.ID).FirstOrDefault();
                string Ima = db.DIPLOM_Sotrydniki.Where(w => w.ID == ID).Select(w => w.Ima).FirstOrDefault();
                MessageBox.Show("Добро пожаловать: " + Ima);
                MenegjerMain main = new MenegjerMain();
                this.Close();
                main.Show();
            }
            //Авторизация для клиента
            else if (db.DIPLOM_Klient.Select(w => w.Login + " " + w.Password).Contains(login.Text + " " + password.Password))
            {
                PublicKlient.Login = login.Text;
                var ID = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();
                string Ima = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Ima).FirstOrDefault();
                MessageBox.Show("Добро пожаловать: " + Ima);
                KlientMain main = new KlientMain();
                this.Close();
                main.Show();
            }
            //Функция появления капчи 
            else
            {
                loginAttempts++;
                if (loginAttempts >= 3)
                {
                    Kaptcha kaptchaWindow = new Kaptcha();
                    this.Close();
                    kaptchaWindow.Show();
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль. Попробуйте еще раз.");
                }
            }
        }

        private void SignIn_Click(object sender, RoutedEventArgs e)
        {
            Registration_Klient_Window regiastration = new Registration_Klient_Window();
            regiastration.Show();
            this.Close();
        }
    }
}
