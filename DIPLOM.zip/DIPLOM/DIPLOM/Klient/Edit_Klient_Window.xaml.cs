﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM
{
    /// <summary>
    /// Interaction logic for Edit_Klient_Window.xaml
    /// </summary>
    public partial class Edit_Klient_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Edit_Klient_Window()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var ID = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();
            txtFamilia.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Familia).FirstOrDefault();
            txtIma.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Ima).FirstOrDefault();
            txtOtchestvo.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Otchestvo).FirstOrDefault();
            DatePicker.SelectedDate = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Data_rojdenia).FirstOrDefault();
            txtTelefon.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Telefon).FirstOrDefault();
            txtSeria.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Pasport_seria).FirstOrDefault();
            txtNomer.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Pasport_nomer).FirstOrDefault();
            txtLogin.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Login).FirstOrDefault();
            txtPassword.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Password).FirstOrDefault();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (txtFamilia.Text == "" || txtIma.Text == "" || txtTelefon.Text == "" || txtSeria.Text == "" || txtNomer.Text == "" || txtLogin.Text == "" || txtPassword.Text == "")
            {
                MessageBox.Show("Не все поля заполнены");
                return;
            }
            else
            {
                var ID = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();
                int x = Convert.ToInt32(ID);

                var str = db.DIPLOM_Klient.Where(w => w.ID == x).FirstOrDefault();
                str.Familia = txtFamilia.Text;
                str.Ima = txtIma.Text;
                str.Otchestvo = txtOtchestvo.Text;
                str.Data_rojdenia = DatePicker.SelectedDate;
                str.Telefon = txtTelefon.Text;
                str.Telefon = txtTelefon.Text;
                str.Pasport_seria = txtSeria.Text;
                str.Pasport_nomer = txtNomer.Text;
                str.Login = txtLogin.Text;
                str.Password = txtPassword.Text;
                db.SaveChanges();

                MessageBox.Show("Запись изменена", "Успешно", MessageBoxButton.OK);
                KlientMain main = new KlientMain();
                main.Show();
                this.Close();
            }
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            KlientMain main = new KlientMain(); 
            main.Show();
            this.Close();
        }

        private void txtFamilia_PreviewTextInput_1(object sender, TextCompositionEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.Text, "^[а-яА-Я]"))
            {
                e.Handled = true;
            }
        }

        private void txtIma_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.Text, "^[а-яА-Я]"))
            {
                e.Handled = true;
            }
        }

        private void txtOtchestvo_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.Text, "^[а-яА-Я]"))
            {
                e.Handled = true;
            }
        }

        private void txtTelefon_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtSeria_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtNomer_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
