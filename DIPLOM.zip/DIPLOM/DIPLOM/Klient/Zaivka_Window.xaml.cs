﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM
{
    /// <summary>
    /// Interaction logic for Zaivka_Window.xaml
    /// </summary>
    public partial class Zaivka_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Zaivka_Window()
        {
            InitializeComponent();
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            KlientMain main = new KlientMain();
            main.Show();
            this.Close();
        }

        private void ClickYslygi(object sender, RoutedEventArgs e)
        {
            Yslygi_Window yslygi = new Yslygi_Window();
            yslygi.Show();
            this.Close();
        }

        private void ClickSotrydnik(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Klient_Window sotrydniki = new Sotrydniki_Klient_Window();
            sotrydniki.Show();
            this.Close();
        }

        private void ZaivkaClick(object sender, RoutedEventArgs e)
        {
            Zaivka_Window zaivka = new Zaivka_Window();
            zaivka.Show();
            this.Close();
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            var CurrentUser = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();

            var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                         join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                         join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                         join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                         where DIPLOM_Zakaz.ID_klienta == CurrentUser
                         select new
                         {
                             ID = DIPLOM_Zakaz.ID,
                             FK = DIPLOM_Sotrydniki.Familia,
                             IK = DIPLOM_Sotrydniki.Ima,
                             OK = DIPLOM_Sotrydniki.Otchestvo,
                             Yslyga = DIPLOM_Yslyga.Nazvanie,
                             Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                             Date = DIPLOM_Zakaz.Data,
                             Cena = DIPLOM_Yslyga.Stoimost
                         };
            membersDataGrid.ItemsSource = result.ToList();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var CurrentUser = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();

            var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                         join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                         join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                         join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                         where DIPLOM_Zakaz.ID_klienta == CurrentUser
                         select new
                         {
                             ID = DIPLOM_Zakaz.ID,
                             FK = DIPLOM_Sotrydniki.Familia,
                             IK = DIPLOM_Sotrydniki.Ima,
                             OK = DIPLOM_Sotrydniki.Otchestvo,
                             Yslyga = DIPLOM_Yslyga.Nazvanie,
                             Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                             Date = DIPLOM_Zakaz.Data,
                             Cena = DIPLOM_Yslyga.Stoimost
                         };
            membersDataGrid.ItemsSource = result.ToList();
            textBoxFilter.Text = "Поиск";
            textBoxFilter.GotFocus += RemoveText;
            textBoxFilter.LostFocus += AddText;
        }
        public void RemoveText(object sender, EventArgs e)
        {
            if (textBoxFilter.Text == "Поиск")
            {
                textBoxFilter.Text = "";
            }
        }
        public void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxFilter.Text))
                textBoxFilter.Text = "Поиск";
        }

        private void textBoxFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textBoxFilter.Text == "")
            {
                var CurrentUser = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();

                var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                             join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                             join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                             join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                             where DIPLOM_Zakaz.ID_klienta == CurrentUser
                             select new
                             {
                                 ID = DIPLOM_Zakaz.ID,
                                 FK = DIPLOM_Sotrydniki.Familia,
                                 IK = DIPLOM_Sotrydniki.Ima,
                                 OK = DIPLOM_Sotrydniki.Otchestvo,
                                 Yslyga = DIPLOM_Yslyga.Nazvanie,
                                 Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                                 Date = DIPLOM_Zakaz.Data,
                                 Cena = DIPLOM_Yslyga.Stoimost
                             };
                membersDataGrid.ItemsSource = result.ToList();
            }
        }

        private void textBoxFilter_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            var CurrentUser = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();

            var result = from DIPLOM_Zakaz in db.DIPLOM_Zakaz
                         join DIPLOM_Sotrydniki in db.DIPLOM_Sotrydniki on DIPLOM_Zakaz.ID_sotrydnika equals DIPLOM_Sotrydniki.ID
                         join DIPLOM_Yslyga in db.DIPLOM_Yslyga on DIPLOM_Zakaz.ID_yslygi equals DIPLOM_Yslyga.ID
                         join DIPLOM_Vid_oplati in db.DIPLOM_Vid_oplati on DIPLOM_Zakaz.ID_vida_oplati equals DIPLOM_Vid_oplati.ID
                         where DIPLOM_Zakaz.ID_klienta == CurrentUser
                         select new
                         {
                             ID = DIPLOM_Zakaz.ID,
                             FK = DIPLOM_Sotrydniki.Familia,
                             IK = DIPLOM_Sotrydniki.Ima,
                             OK = DIPLOM_Sotrydniki.Otchestvo,
                             Yslyga = DIPLOM_Yslyga.Nazvanie,
                             Oplata = DIPLOM_Vid_oplati.Vid_oplati,
                             Date = DIPLOM_Zakaz.Data,
                             Cena = DIPLOM_Yslyga.Stoimost
                         };
            membersDataGrid.ItemsSource = result.Where(item => item.FK == textBoxFilter.Text || item.FK.Contains(textBoxFilter.Text) ||
            item.IK == textBoxFilter.Text || item.IK.Contains(textBoxFilter.Text) ||
            item.OK == textBoxFilter.Text || item.OK.Contains(textBoxFilter.Text) ||
            item.Yslyga == textBoxFilter.Text || item.Yslyga.Contains(textBoxFilter.Text)
            ).ToList();
        }
    }
}
