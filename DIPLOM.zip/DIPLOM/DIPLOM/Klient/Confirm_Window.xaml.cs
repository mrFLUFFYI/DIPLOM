﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Klient
{
    /// <summary>
    /// Interaction logic for Confirm_Window.xaml
    /// </summary>
    public partial class Confirm_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Confirm_Window()
        {
            InitializeComponent();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (db.DIPLOM_Klient.Select(w => w.Password + w.Login).Contains(txtPassword.Text + PublicKlient.Login))
            {
                Edit_Klient_Window edit = new Edit_Klient_Window();
                edit.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный пароль");
            }
        }

        private void EditBtn_Click(object sender, RoutedEventArgs e)
        {
            KlientMain main = new KlientMain();
            main.Show();
            this.Close();
        }
    }
}
