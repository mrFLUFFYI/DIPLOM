﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM.Klient
{
    /// <summary>
    /// Interaction logic for Registration_Klient_Window.xaml
    /// </summary>
    public partial class Registration_Klient_Window : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public Registration_Klient_Window()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Backbtb_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow auth = new AuthorizationWindow();
            auth.Show();
            this.Close();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (txtFamilia.Text == "" || txtIma.Text == "" || txtTelefon.Text == "" || txtSeria.Text == "" || txtNomer.Text == "" || txtLogin.Text == "" || txtPassword.Text == "")
            {
                MessageBox.Show("Не все поля заполнены");
                return;
            }
            else
            {
                DIPLOM_Klient klient = new DIPLOM_Klient();
                klient.Familia = txtFamilia.Text;
                klient.Ima = txtIma.Text;
                klient.Otchestvo = txtOtchestvo.Text;
                klient.Data_rojdenia = DatePicker.SelectedDate;
                klient.Telefon = txtTelefon.Text;
                klient.Telefon = txtTelefon.Text;
                klient.Pasport_seria = txtSeria.Text;
                klient.Pasport_nomer = txtNomer.Text;
                klient.Login = txtLogin.Text;
                klient.Password = txtPassword.Text;
                db.DIPLOM_Klient.Add(klient);
                db.SaveChanges();

                MessageBox.Show("Регистрация прошла успешно", "Успешно", MessageBoxButton.OK);
                AuthorizationWindow auth = new AuthorizationWindow();
                auth.Show();
                this.Close();
            }
        }
        private void txtFamilia_PreviewTextInput_1(object sender, TextCompositionEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.Text, "^[а-яА-Я]"))
            {
                e.Handled = true;
            }
        }

        private void txtIma_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.Text, "^[а-яА-Я]"))
            {
                e.Handled = true;
            }
        }

        private void txtOtchestvo_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.Text, "^[а-яА-Я]"))
            {
                e.Handled = true;
            }
        }

        private void txtTelefon_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtSeria_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void txtNomer_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
