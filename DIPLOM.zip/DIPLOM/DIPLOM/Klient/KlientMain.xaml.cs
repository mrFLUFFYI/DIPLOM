﻿using DIPLOM.Klient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM
{
    /// <summary>
    /// Interaction logic for KlientMain.xaml
    /// </summary>
    public partial class KlientMain : Window
    {
        user145_dbEntities db = new user145_dbEntities();
        public KlientMain()
        {
            InitializeComponent();
        }

        private void ClickYslygi(object sender, RoutedEventArgs e)
        {
            Yslygi_Window yslygi = new Yslygi_Window();
            yslygi.Show();
            this.Close();
        }

        private void ClickSotrydnik(object sender, RoutedEventArgs e)
        {
            Sotrydniki_Klient_Window sotrydniki = new Sotrydniki_Klient_Window();
            sotrydniki.Show();
            this.Close();
        }

        private void ZaivkaClick(object sender, RoutedEventArgs e)
        {
            Zaivka_Window zaivka = new Zaivka_Window();
            zaivka.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var ID = db.DIPLOM_Klient.Where(w => w.Login == PublicKlient.Login).Select(w => w.ID).FirstOrDefault();
            txtFamilia.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Familia).FirstOrDefault();
            txtIma.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Ima).FirstOrDefault();
            txtOtchestvo.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Otchestvo).FirstOrDefault();
            txtdata.Text = Convert.ToString(db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Data_rojdenia).FirstOrDefault());
            txtTelefon.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Telefon).FirstOrDefault();
            txtSeria.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Pasport_seria).FirstOrDefault();
            txtNomer.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Pasport_nomer).FirstOrDefault();
            txtLogin.Text = db.DIPLOM_Klient.Where(w => w.ID == ID).Select(w => w.Login).FirstOrDefault();

        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MaxBtn_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                if (WindowState == WindowState.Maximized)
                {
                    WindowState = WindowState.Normal;
                }
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            KlientMain main = new KlientMain();
            main.Show();
            this.Close();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            Confirm_Window confirm = new Confirm_Window();
            confirm.Show();
            this.Close();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            AuthorizationWindow auth = new AuthorizationWindow();
            auth.Show();
            this.Close();
        }
    }
}
