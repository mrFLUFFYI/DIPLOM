﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DIPLOM
{
    /// <summary>
    /// Interaction logic for About_Yslygi_Window.xaml
    /// </summary>
    public partial class About_Yslygi_Window : Window
    {
        user145_dbEntities db  = new user145_dbEntities();
        string about = PublicYslygi.about;
        public About_Yslygi_Window()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var query = from DIPLOM_Yslyga in db.DIPLOM_Yslyga
                        where DIPLOM_Yslyga.Nazvanie == about
                        select new
                        {
                            Nazvanie = DIPLOM_Yslyga.Nazvanie,
                            Cena = DIPLOM_Yslyga.Stoimost,
                            Opisanie = DIPLOM_Yslyga.Opisanie
                        };
            var res = query.FirstOrDefault();

            nazvanie_lbl.Content = res.Nazvanie;
            cena_lbl.Content = res.Cena;
            opisanie_lbl.Text = res.Opisanie;
        }

        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
