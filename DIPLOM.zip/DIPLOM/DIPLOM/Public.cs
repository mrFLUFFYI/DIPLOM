﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIPLOM
{
    internal class PublicSotr
    {
        public static int index { get; set; }
        public static int ID { get; set; }
        public static string Familia { get; set; }
        public static string Name { get; set; }
        public static string Otchestvo {  get; set; }
        public static DateTime Data_rojdenia { get; set; }
        public static string Email { get; set; }
        public static string Adress { get; set; }
        public static string Pasport_seria { get; set; }
        public static string Pasport_nomer { get; set; }
        public static string Telefon { get; set; }
        public static string Login { get; set; }
        public static string Password { get; set; }
    }
    internal class PublicKlient
    {
        public static int index { get; set; }
        public static int ID { get; set; }
        public static string Familia { get; set; }
        public static string Ima { get; set; }
        public static string Otchestvo {get; set;}
        public static string Telefon { get; set;}
        public static DateTime Data_rojdenia { get; set; }
        public static string Pasport_seria { get; set;}
        public static string Pasport_nomer { get; set;}
        public static string Login { get; set; }
        public static string Password { get; set; }
    }
    internal class PublicYslygi
    {
        public static string about { get; set; }
    }

    internal class PublicCar
    {
        public static int index { get; set; }
        public static int ID { get; set; }
        public static int ID_klienta { get; set; }
        public static string Nomer_avtomobila { get; set; }
        public static int ID_Marki { get; set; }
        public static int ID_modeli { get; set; }
        public static int ID_kyzova { get; set; }
        public static string God { get; set; }
    }

    internal class PublicZaivka
    {
        public static int index { get; set; }
        public static int ID { get; set; }
        public static int ID_klienta { get; set; }
        public static int ID_sotrydnika { get; set; }
        public static int ID_vida_oplati { get; set; }
        public static int ID_yslygi { get; set; }
        public static DateTime Data { get; set; }
    }

}
